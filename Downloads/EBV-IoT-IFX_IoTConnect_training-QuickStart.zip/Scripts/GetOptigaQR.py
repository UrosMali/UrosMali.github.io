#!/usr/bin/env python
#optigaQR.py
import qrcode
import optigatrust as optiga
import base64
from PIL import Image

ans = ""

chip = optiga.Chip()

for item in chip.uid:
   ans = ans + item

print("\n")
print ("Unique Id:")
UID = base64.b64encode(bytes.fromhex(ans)).decode()[0:31]
print(UID)
print("\n")

#Creating an instance of qrcode
qr = qrcode.QRCode(
        version=1,
        box_size=10,
        border=5)
qr.add_data(UID)
qr.make(fit=True)
img = qr.make_image(fill='black', back_color='white')
img.save('qrcode001.png')

with Image.open('qrcode001.png') as img:
    img.show()
