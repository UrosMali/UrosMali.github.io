#!/usr/bin/env python
import optigatrust as optiga
from optigatrust import objects

from OpenSSL.crypto import load_certificate, FILETYPE_PEM
import base64

from optigatrust import port
import json

ans = ""
ENV = b'avnetpoc'
CPID = b'c0805f4fba2e43a984c052933612adf1'

#UID
#This property allows to get a Coprocessor Unique ID.
#It will be returned as a namedtuple class.
chip = optiga.Chip()

for item in chip.uid:
   #print(item)
   ans = ans + item
#print("\n" + ans + "\n")
print("\n")

print ("Unique Id:")
print (base64.b64encode(bytes.fromhex(ans)).decode()[0:31])
print("\n")


#Output the certificate Thumbprint
cert_object = objects.X509(0xe0e0)

cert = load_certificate(FILETYPE_PEM, cert_object.pem)
sha1_fingerprint = cert.digest("sha1")
print ("Thumbprint:")
print (sha1_fingerprint.lower().decode('ASCII').replace(':', ''))
#print("\n")

#Write data to Optiga  
# Create an instance of object for ENV storage
cert_object = optiga.Object(0xf1d2)
#print(cert_object.read().hex())

cert_object.write(ENV)
#print(cert_object.read().hex())
#print(cert_object.read().decode('ASCII'))

# Read object data
#print(json.dumps(cert_object.meta, indent=4))


# Create an instance of object for CPID storage
cert_object = optiga.Object(0xf1d3)
#print(cert_object.read().hex())

cert_object.write(CPID)
#print(cert_object.read().hex())
#print(cert_object.read().decode('ASCII'))

# Read object data
#print(json.dumps(cert_object.meta, indent=4))